Paper 01 standalone notebook v2

Upload the .ipynb directly to Colab/Jupyter and run cells in order. The first code cell restores the three bundled Python scripts in ./support automatically. A network connection is needed for GitHub data; Google Drive requires access and real-data mappings. Simulated results must not be represented as measured factory data.
